import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    String[] bulan = {
        "Januari",
        "Februari",
        "Maret",
        "April",
        "Mei",
        "Juni",
        "Juli",
        "Agustus",
        "September",
        "Oktober",
        "November",
        "Desember",
    };
    
    Scanner n = new Scanner (System.in);
    int tanggal = n.nextInt();
    int nobulan = n.nextInt();
    int tahun = n.nextInt();
    
      System.out.print(tanggal + bulan[nobulan-1] + tahun);
      
  }
}
    
